import { Menu, Bell, Calendar, GraduationCap, Users, BarChart3, ChevronLeft, ChevronRight, Plus, X, Settings, HelpCircle, LogOut, Banknote } from 'lucide-react';
import { useState } from 'react';
import { TodayStatus } from './components/TodayStatus';
import { AllStudents } from './components/AllStudents';
import { AllTeachers } from './components/AllTeachers';
import { SettingsPage } from './components/SettingsPage';
import { StudentRegisterModal } from './components/StudentRegisterModal';
import { TeacherRegisterModal } from './components/TeacherRegisterModal';
import { ClassRegisterModal } from './components/ClassRegisterModal';
import { ClassStudentListModal } from './components/ClassStudentListModal';
import { Header } from './components/Header';
import { RegisterBottomSheet } from './components/RegisterBottomSheet';
import { StudentDetailPage } from './components/StudentDetailPage';
import { TeacherDetailPage } from './components/TeacherDetailPage';
import { LoginPage } from './components/LoginPage';
import React from 'react';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [selectedDay, setSelectedDay] = useState(1);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isRegisterBottomSheetOpen, setIsRegisterBottomSheetOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<'home' | 'todayStatus' | 'allStudents' | 'allTeachers' | 'settings' | 'studentDetail' | 'teacherDetail'>('home');
  const [isStudentRegisterModalOpen, setIsStudentRegisterModalOpen] = useState(false);
  const [isTeacherRegisterModalOpen, setIsTeacherRegisterModalOpen] = useState(false);
  const [isClassRegisterModalOpen, setIsClassRegisterModalOpen] = useState(false);
  const [isClassStudentListModalOpen, setIsClassStudentListModalOpen] = useState(false);
  const [mainColor, setMainColor] = useState('#3b82f6'); // 기본 파란색
  const [zones, setZones] = useState([
    { name: '1층', rooms: ['101호', '102호', '103호'] },
    { name: '2층', rooms: ['201호', '202호'] },
    { name: '3층', rooms: ['301호'] },
  ]);
  const [selectedZone, setSelectedZone] = useState<string>('전체');
  const [selectedClassInfo, setSelectedClassInfo] = useState<{
    title: string;
    time: string;
    room: string;
    teacher: string;
    level: string;
    students: number;
  } | null>(null);
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);
  const [selectedTeacherId, setSelectedTeacherId] = useState<number | null>(null);
  
  // 운영 시간 설정
  const [operatingHours] = useState({
    monday: { open: '09:00', close: '22:00', isOpen: true },
    tuesday: { open: '09:00', close: '22:00', isOpen: true },
    wednesday: { open: '09:00', close: '22:00', isOpen: true },
    thursday: { open: '09:00', close: '22:00', isOpen: true },
    friday: { open: '09:00', close: '22:00', isOpen: true },
    saturday: { open: '10:00', close: '18:00', isOpen: true },
    sunday: { open: '10:00', close: '18:00', isOpen: false }
  });

  // 과목 설정
  const [subjects] = useState([
    { name: '한국어 기초', color: '#3b82f6' },
    { name: '한국어 중급', color: '#10b981' },
    { name: '한국어 고급', color: '#8b5cf6' },
    { name: '회화', color: '#ec4899' },
    { name: '문법', color: '#eab308' }
  ]);
  
  // 출석 데이터 저장 (실제로는 서버에 저장)
  const [attendanceData, setAttendanceData] = useState<{
    [studentId: number]: {
      date: string;
      status: string;
    }[]
  }>({});

  const handleSaveAttendance = (data: { 
    date: string; 
    attendanceData: { studentId: number; studentName: string; status: string }[] 
  }) => {
    const newAttendanceData = { ...attendanceData };
    
    data.attendanceData.forEach(item => {
      if (!newAttendanceData[item.studentId]) {
        newAttendanceData[item.studentId] = [];
      }
      
      // 같은 날짜의 기존 출석 기록이 있다면 업데이트, 없으면 추가
      const existingIndex = newAttendanceData[item.studentId].findIndex(
        record => record.date === data.date
      );
      
      if (existingIndex >= 0) {
        newAttendanceData[item.studentId][existingIndex].status = item.status;
      } else {
        newAttendanceData[item.studentId].push({
          date: data.date,
          status: item.status
        });
      }
    });
    
    setAttendanceData(newAttendanceData);
    console.log('출석 데이터 저장됨:', newAttendanceData);
  };

  const stats = [
    {
      icon: <Banknote className="w-8 h-8 text-blue-500" />,
      value: '₩8,830,000',
      unit: '',
      label: '금일 현황',
      link: '자세 보기 →'
    },
    {
      icon: <Users className="w-8 h-8 text-green-500" />,
      value: '125',
      unit: '명',
      label: '전체 학생',
      link: '자세히 보기 →'
    },
    {
      icon: <GraduationCap className="w-8 h-8 text-purple-500" />,
      value: '8',
      unit: '',
      label: '전체 선생님',
      link: '자세히 보기 →'
    }
  ];

  const days = ['월', '화', '수', '목', '금', '토', '일'];
  const rooms = ['축구장', '농구장', '배드민턴장', '발레실', '댄스실'];
  const timeSlots = ['9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'];

  // 모든 강의실 목록 (zones에서 추출)
  const allRooms = zones.flatMap(zone => zone.rooms);
  
  // 강의실이 6개를 넘으면 전체 보기 버튼 숨김
  const showAllButton = allRooms.length <= 6;
  
  // 선택된 구역에 따라 표시할 강의실 필터링
  const displayRooms = selectedZone === '전체' 
    ? allRooms 
    : zones.find(zone => zone.name === selectedZone)?.rooms || [];
  
  // 전체 버튼이 숨겨져 있고 현재 전체가 선택되어 있으면 첫 번째 구역으로 변경
  if (!showAllButton && selectedZone === '전체' && zones.length > 0) {
    setSelectedZone(zones[0].name);
  }

  // 강의실별 시간표 데이터 (요일별로)
  const scheduleByDay: Record<number, any[]> = {
    1: [ // 월요일
      {
        room: '101호',
        time: '12:00',
        title: '발야흥',
        teacher: '김민지',
        level: '초급',
        students: 10,
        color: 'bg-pink-50 border-pink-200'
      },
      {
        room: '102호',
        time: '14:00',
        title: '농구 중급반',
        teacher: '이수진',
        level: '중급',
        students: 15,
        color: 'bg-green-50 border-green-200'
      }
    ],
    2: [ // 화요일
      {
        room: '103호',
        time: '10:00',
        title: '배드민턴 중급반',
        teacher: '최정훈',
        level: '중급',
        students: 12,
        color: 'bg-yellow-50 border-yellow-200'
      },
      {
        room: '201호',
        time: '15:00',
        title: '댄스 초급반',
        teacher: '강민수',
        level: '초급',
        students: 20,
        color: 'bg-orange-50 border-orange-200'
      }
    ],
    3: [ // 수요일
      {
        room: '101호',
        time: '11:00',
        title: '축구 초급반',
        teacher: '김민지',
        level: '초급',
        students: 18,
        color: 'bg-blue-50 border-blue-200'
      }
    ],
    4: [ // 목요일
      {
        room: '102호',
        time: '9:00',
        title: '농구 중급반',
        teacher: '이수진',
        level: '중급',
        students: 15,
        color: 'bg-green-50 border-green-200'
      }
    ],
    5: [ // 금요일
      {
        room: '201호',
        time: '13:00',
        title: '댄스 초급반',
        teacher: '강민수',
        level: '초급',
        students: 20,
        color: 'bg-orange-50 border-orange-200'
      }
    ],
    6: [ // 토요일
      {
        room: '101호',
        time: '10:00',
        title: '축구 초급반',
        teacher: '김민지',
        level: '초급',
        students: 18,
        color: 'bg-blue-50 border-blue-200'
      }
    ],
    7: [ // 일요일
      {
        room: '102호',
        time: '11:00',
        title: '농구 중급반',
        teacher: '이수진',
        level: '중급',
        students: 15,
        color: 'bg-green-50 border-green-200'
      }
    ]
  };

  const currentSchedule = scheduleByDay[selectedDay] || [];

  // 로그인 체크
  if (!isLoggedIn) {
    return <LoginPage onLogin={() => setIsLoggedIn(true)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Sidebar Overlay */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed top-0 left-0 h-full w-64 bg-white shadow-lg z-50 transform transition-transform duration-300 ${
        isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
      }`}>
        {/* Sidebar Header */}
        <div className="bg-slate-700 text-white p-4 flex items-center justify-between">
          <h2 className="text-lg">메뉴</h2>
          <button 
            onClick={() => setIsSidebarOpen(false)}
            className="p-1 hover:bg-slate-600 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sidebar Menu */}
        <nav className="p-4">
          <ul className="space-y-2">
            <li>
              <button 
                className="w-full flex items-center gap-3 p-3 hover:bg-gray-100 rounded text-gray-700"
                onClick={() => {
                  setCurrentPage('allStudents');
                  setIsSidebarOpen(false);
                }}
              >
                <Users className="w-5 h-5 text-green-600" />
                <span>전체 학생 페이지</span>
              </button>
            </li>
            <li>
              <button 
                className="w-full flex items-center gap-3 p-3 hover:bg-gray-100 rounded text-gray-700"
                onClick={() => {
                  setCurrentPage('allTeachers');
                  setIsSidebarOpen(false);
                }}
              >
                <GraduationCap className="w-5 h-5 text-yellow-600" />
                <span>전체 선생님 페이지</span>
              </button>
            </li>
            <li>
              <button
                className="w-full flex items-center gap-3 p-3 hover:bg-gray-100 rounded text-blue-500"
                onClick={() => {
                  setIsRegisterBottomSheetOpen(true);
                  setIsSidebarOpen(false);
                }}
              >
                <Plus className="w-5 h-5" />
                <span>등록</span>
              </button>
            </li>
            <li>
              <button 
                className="w-full flex items-center gap-3 p-3 hover:bg-gray-100 rounded text-gray-700"
                onClick={() => {
                  setCurrentPage('settings');
                  setIsSidebarOpen(false);
                }}
              >
                <Settings className="w-5 h-5 text-gray-500" />
                <span>설정</span>
              </button>
            </li>
            <li>
              <button className="w-full flex items-center gap-3 p-3 hover:bg-gray-100 rounded text-gray-700">
                <HelpCircle className="w-5 h-5 text-gray-500" />
                <span>도움말</span>
              </button>
            </li>
            <li>
              <button className="w-full flex items-center gap-3 p-3 hover:bg-gray-100 rounded text-gray-700">
                <LogOut className="w-5 h-5 text-gray-500" />
                <span>로그아웃</span>
              </button>
            </li>
          </ul>
        </nav>
      </div>

      {/* Header */}
      <Header 
        onMenuClick={() => setIsSidebarOpen(true)}
        onSettingsClick={() => setCurrentPage('settings')}
        onHomeClick={() => setCurrentPage('home')}
      />

      {/* Main Content */}
      <main className="p-4">
        {currentPage === 'home' && (
          <>
            {/* Stats Section */}
            <section className="mb-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {stats.map((stat, index) => (
                  <div key={index} className="bg-white rounded-lg border border-gray-200 p-6">
                    <div className="text-center mb-2">
                      <div className="text-sm text-gray-600 mb-3">{stat.label}</div>
                    </div>
                    <div className="flex justify-center mb-3">
                      {stat.icon}
                    </div>
                    <div className="text-center mb-2">
                      <div className="text-gray-800 mb-1 h-[36px] flex items-center justify-center">
                        <span className="text-3xl">{stat.value}</span>
                        <span className="text-lg">{stat.unit}</span>
                      </div>
                    </div>
                    <div className="text-center">
                      <a 
                        href="#" 
                        className="text-blue-500 text-sm hover:underline"
                        onClick={(e) => {
                          e.preventDefault();
                          if (index === 0) { // 금일 현황 카드
                            setCurrentPage('todayStatus');
                          } else if (index === 1) { // 전체 학생 카드
                            setCurrentPage('allStudents');
                          } else if (index === 2) { // 전체 선생님 카드
                            setCurrentPage('allTeachers');
                          }
                        }}
                      >
                        {stat.link}
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Schedule Section */}
            <section>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <h2 className="text-gray-800">전체 시간표</h2>
                  <div className="flex gap-2">
                    {showAllButton && (
                      <button
                        onClick={() => setSelectedZone('전체')}
                        className={`px-4 h-10 rounded text-sm transition-colors ${
                          selectedZone === '전체'
                            ? 'bg-blue-500 text-white'
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        전체
                      </button>
                    )}
                    {zones.map((zone, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedZone(zone.name)}
                        className={`px-4 h-10 rounded text-sm transition-colors ${
                          selectedZone === zone.name
                            ? 'bg-blue-500 text-white'
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {zone.name}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-2 items-center">
                  <div className="flex gap-2">
                    {days.map((day, index) => (
                      <button
                        key={index}
                        onClick={() => setSelectedDay(index + 1)}
                        className={`w-10 h-10 rounded flex items-center justify-center transition-colors ${
                          selectedDay === index + 1
                            ? 'bg-blue-500 text-white'
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {day}
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={() => setIsRegisterBottomSheetOpen(true)}
                    className="flex items-center gap-2 px-4 h-10 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>등록 하기</span>
                  </button>
                </div>
              </div>
              
              {/* Schedule Table */}
              <div className="bg-white rounded-lg border border-gray-200 overflow-auto">
                <table className="w-full border-collapse">
                  {/* Table Header */}
                  <thead>
                    <tr>
                      <th className="sticky left-0 bg-gray-50 px-4 py-3 border-r border-b border-gray-200 text-sm text-gray-700 text-center min-w-[100px]">
                        시간
                      </th>
                      {displayRooms.map((room, index) => (
                        <th key={index} className="bg-white px-4 py-3 border-r border-b border-gray-200 last:border-r-0 text-sm text-gray-700 text-center min-w-[200px]">
                          {room}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  
                  {/* Table Body */}
                  <tbody>
                    {timeSlots.map((time, timeIndex) => (
                      <tr key={timeIndex}>
                        {/* Time Column */}
                        <td className="sticky left-0 bg-gray-50 px-4 py-4 border-r border-b border-gray-200 text-sm text-gray-600 text-center">
                          {time}
                        </td>
                        
                        {/* Room Columns */}
                        {displayRooms.map((room, roomIndex) => {
                          const classInfo = scheduleByDay[selectedDay]?.find(
                            (schedule) => schedule.room === room && schedule.time === time
                          );
                          
                          return (
                            <td key={roomIndex} className="border-r border-b border-gray-200 last:border-r-0 p-2 min-h-[80px] hover:bg-gray-50 transition-colors">
                              {classInfo && (
                                <button
                                  onClick={() => {
                                    setSelectedClassInfo(classInfo);
                                    setIsClassStudentListModalOpen(true);
                                  }}
                                  className="w-full bg-pink-50 border border-pink-200 rounded p-3 text-left hover:bg-pink-100 transition-colors"
                                >
                                  <div className="flex items-start justify-between mb-1">
                                    <p className="text-sm text-pink-900">{classInfo.title}</p>
                                  </div>
                                  <p className="text-xs text-pink-700">{classInfo.teacher} · {classInfo.level}</p>
                                  <p className="text-xs text-pink-600 mt-1">
                                    {classInfo.students} 명 / 0명 결석
                                  </p>
                                </button>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </>
        )}
        
        {currentPage === 'todayStatus' && (
          <TodayStatus 
            onBack={() => setCurrentPage('home')} 
            onStudentClick={(studentId) => {
              setSelectedStudentId(studentId);
              setCurrentPage('studentDetail');
            }}
            onTeacherClick={(teacherId) => {
              setSelectedTeacherId(teacherId);
              setCurrentPage('teacherDetail');
            }}
            onRegisterClick={() => setIsRegisterBottomSheetOpen(true)}
          />
        )}
        
        {currentPage === 'allStudents' && (
          <AllStudents 
            onBack={() => setCurrentPage('home')}
            onStudentClick={(studentId) => {
              setSelectedStudentId(studentId);
              setCurrentPage('studentDetail');
            }}
            onRegisterClick={() => setIsRegisterBottomSheetOpen(true)}
          />
        )}
        
        {currentPage === 'allTeachers' && (
          <AllTeachers 
            onBack={() => setCurrentPage('home')}
            onTeacherClick={(teacherId) => {
              setSelectedTeacherId(teacherId);
              setCurrentPage('teacherDetail');
            }}
            onRegisterClick={() => setIsRegisterBottomSheetOpen(true)}
          />
        )}
        
        {currentPage === 'settings' && (
          <SettingsPage 
            onBack={() => setCurrentPage('home')}
            mainColor={mainColor}
            onMainColorChange={(color) => setMainColor(color)}
            zones={zones}
            onZonesChange={(newZones) => setZones(newZones)}
          />
        )}
        
        {currentPage === 'studentDetail' && (
          <StudentDetailPage 
            onBack={() => setCurrentPage('allStudents')}
            studentId={selectedStudentId}
          />
        )}
        
        {currentPage === 'teacherDetail' && (
          <TeacherDetailPage 
            onBack={() => setCurrentPage('allTeachers')}
            teacherId={selectedTeacherId}
          />
        )}
      </main>

      {/* Student Register Modal */}
      <StudentRegisterModal 
        isOpen={isStudentRegisterModalOpen} 
        onClose={() => setIsStudentRegisterModalOpen(false)} 
      />

      {/* Teacher Register Modal */}
      <TeacherRegisterModal 
        isOpen={isTeacherRegisterModalOpen} 
        onClose={() => setIsTeacherRegisterModalOpen(false)}
        operatingHours={operatingHours}
        subjects={subjects}
      />

      {/* Class Register Modal */}
      <ClassRegisterModal 
        isOpen={isClassRegisterModalOpen} 
        onClose={() => setIsClassRegisterModalOpen(false)} 
      />

      {/* Class Student List Modal */}
      <ClassStudentListModal 
        isOpen={isClassStudentListModalOpen} 
        onClose={() => setIsClassStudentListModalOpen(false)} 
        classInfo={selectedClassInfo}
        onSaveAttendance={handleSaveAttendance}
        onStudentClick={(studentId) => {
          setSelectedStudentId(studentId);
          setIsClassStudentListModalOpen(false);
          setCurrentPage('studentDetail');
        }}
      />

      {/* Register Bottom Sheet */}
      <RegisterBottomSheet
        isOpen={isRegisterBottomSheetOpen}
        onClose={() => setIsRegisterBottomSheetOpen(false)}
        onClassRegister={() => {
          setIsRegisterBottomSheetOpen(false);
          setIsClassRegisterModalOpen(true);
        }}
        onTeacherRegister={() => {
          setIsRegisterBottomSheetOpen(false);
          setIsTeacherRegisterModalOpen(true);
        }}
        onStudentRegister={() => {
          setIsRegisterBottomSheetOpen(false);
          setIsStudentRegisterModalOpen(true);
        }}
      />
    </div>
  );
}