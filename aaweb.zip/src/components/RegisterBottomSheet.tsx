import { Calendar, GraduationCap, Users, X } from 'lucide-react';

interface RegisterBottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  onClassRegister: () => void;
  onTeacherRegister: () => void;
  onStudentRegister: () => void;
}

export function RegisterBottomSheet({ 
  isOpen, 
  onClose, 
  onClassRegister, 
  onTeacherRegister, 
  onStudentRegister 
}: RegisterBottomSheetProps) {
  if (!isOpen) return null;

  return (
    <>
      {/* Overlay */}
      <div 
        className="fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity"
        onClick={onClose}
      />
      
      {/* Bottom Sheet */}
      <div className="fixed bottom-0 left-0 right-0 bg-white rounded-t-2xl shadow-lg z-50 animate-slide-up">
        {/* Handle */}
        <div className="flex justify-center pt-3 pb-2">
          <div className="w-12 h-1 bg-gray-300 rounded-full" />
        </div>
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-3 border-b border-gray-200">
          <h3 className="text-lg text-gray-800">등록하기</h3>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        {/* Menu Items */}
        <div className="px-6 py-4">
          <button 
            className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-lg transition-colors border-b border-gray-100"
            onClick={() => {
              onTeacherRegister();
              onClose();
            }}
          >
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-purple-500" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-gray-800">선생님 등록</div>
              <div className="text-sm text-gray-500">새로운 선생님을 등록합니다</div>
            </div>
          </button>
          
          <button 
            className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-lg transition-colors border-b border-gray-100"
            onClick={() => {
              onClassRegister();
              onClose();
            }}
          >
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Calendar className="w-6 h-6 text-blue-500" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-gray-800">수업 등록</div>
              <div className="text-sm text-gray-500">새로운 수업을 등록합니다</div>
            </div>
          </button>
          
          <button 
            className="w-full flex items-center gap-4 p-4 hover:bg-gray-50 rounded-lg transition-colors"
            onClick={() => {
              onStudentRegister();
              onClose();
            }}
          >
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
              <Users className="w-6 h-6 text-green-500" />
            </div>
            <div className="flex-1 text-left">
              <div className="text-gray-800">학생 등록</div>
              <div className="text-sm text-gray-500">새로운 학생을 등록합니다</div>
            </div>
          </button>
        </div>
        
        {/* Safe Area Bottom Padding */}
        <div className="h-8" />
      </div>
    </>
  );
}