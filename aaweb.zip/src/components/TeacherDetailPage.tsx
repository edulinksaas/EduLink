import { Edit, Pencil } from 'lucide-react';
import { useState } from 'react';
import { StudentRegisterModal } from './StudentRegisterModal';
import { TeacherRegisterModal } from './TeacherRegisterModal';
import { ClassRegisterModal } from './ClassRegisterModal';
import { ClassStudentListModal } from './ClassStudentListModal';

interface TeacherDetailPageProps {
  teacherName: string;
  onBack: () => void;
}

export function TeacherDetailPage({ teacherName, onBack }: TeacherDetailPageProps) {
  const [selectedWeekDays, setSelectedWeekDays] = useState(['월', '화', '수', '목', '금']);
  const [isWeeklyRegisterDropdownOpen, setIsWeeklyRegisterDropdownOpen] = useState(false);
  const [isWeekendRegisterDropdownOpen, setIsWeekendRegisterDropdownOpen] = useState(false);
  const [isStudentRegisterModalOpen, setIsStudentRegisterModalOpen] = useState(false);
  const [isTeacherRegisterModalOpen, setIsTeacherRegisterModalOpen] = useState(false);
  const [isClassRegisterModalOpen, setIsClassRegisterModalOpen] = useState(false);
  const [isClassStudentListModalOpen, setIsClassStudentListModalOpen] = useState(false);
  const [selectedClassInfo, setSelectedClassInfo] = useState<{
    title: string;
    time: string;
    room: string;
    teacher: string;
    level: string;
  } | null>(null);
  const [scheduleType, setScheduleType] = useState<'평일' | '주말'>('평일');

  const weekDays = ['월', '화', '수', '목', '금'];
  const weekendDays = ['토', '일'];
  const subjects = ['풀레이', '농구', '세종 대왕', '배드민턴', '발레', '자연에 축구'];

  const subjectColors: { [key: string]: string } = {
    '풀레이': 'bg-blue-100 text-blue-700 border-blue-300',
    '농구': 'bg-orange-100 text-orange-700 border-orange-300',
    '세종 대왕': 'bg-yellow-100 text-yellow-700 border-yellow-300',
    '배드민턴': 'bg-green-100 text-green-700 border-green-300',
    '발레': 'bg-pink-100 text-pink-700 border-pink-300',
    '자연에 축구': 'bg-purple-100 text-purple-700 border-purple-300'
  };

  const schedule = {
    월: [
      { time: '13:00', title: '후 배드민턴 초급', level: '초급반', room: '배드민턴장', color: 'bg-green-100 border-green-300' },
      { time: '14:00', title: '후 배드민턴 초급', level: '초급반', room: '배드민턴장', color: 'bg-green-100 border-green-300' }
    ],
    화: [
      { time: '13:00', title: '오후 발레 초급', level: '중급 반', room: '발레 스튜디오', color: 'bg-pink-100 border-pink-300' },
      { time: '15:00', title: '어린이 농구 초급', level: '초급반', room: '농구장', color: 'bg-green-100 border-green-300' },
      { time: '17:00', title: '어린이 농구 초급', level: '초급반', room: '농구장', color: 'bg-blue-100 border-blue-300' },
      { time: '20:00', title: '오후 풀 교정반 초급', level: '초급 반', room: '풀레이장', color: 'bg-pink-100 border-pink-300' },
      { time: '21:00', title: '오후 풀 교정반 초급', level: '초급 반', room: '풀레이장', color: 'bg-pink-100 border-pink-300' }
    ],
    수: [
      { time: '15:00', title: '어린이 농구 초급', level: '초급반', room: '농구장', color: 'bg-green-100 border-green-300' }
    ],
    목: [
      { time: '15:00', title: '어린이 축구 초급', level: '고급반 초급', room: '축구장', color: 'bg-green-100 border-green-300' },
      { time: '16:00', title: '어 어린이 축구 초급', level: '초 초급반', room: '축구장', color: 'bg-red-100 border-red-300' },
      { time: '19:00', title: '후 세종대왕 초급', level: '초급반', room: '세종홀', color: 'bg-yellow-100 border-yellow-300' },
      { time: '20:00', title: '후 축구 어린이', level: '중 초급반', room: '축구장', color: 'bg-yellow-100 border-yellow-300' }
    ],
    금: [
      { time: '13:00', title: '후 배드민턴 초급', level: '초급반', room: '배드민턴장', color: 'bg-green-100 border-green-300' }
    ]
  };

  const weekendSchedule = {
    토: [
      { time: '14:00', title: '주말 축구 초급', level: '초급반', room: '축구장', color: 'bg-purple-100 border-purple-300' },
      { time: '16:00', title: '주말 농구 중급', level: '중급반', room: '농구', color: 'bg-orange-100 border-orange-300' }
    ],
    일: [
      { time: '10:00', title: '일요일 발레', level: '고급반', room: '발레 스튜디오', color: 'bg-pink-100 border-pink-300' },
      { time: '15:00', title: '주말 배드민턴', level: '초급반', room: '배드민턴장', color: 'bg-green-100 border-green-300' }
    ]
  };

  const timeSlots = [
    '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00'
  ];

  const weekendTimeSlots = [
    '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00'
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-4">
          <div className="text-sm text-gray-600 mb-1">선생님 이름</div>
          <h1 className="text-2xl text-gray-800 mb-2">{teacherName}</h1>
          <p className="text-sm text-red-500">연락처: 010 9158 7124</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="text-sm text-gray-600 mb-2">월 신규 등록 인원</div>
            <div className="text-2xl text-gray-800">12명</div>
          </div>
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="text-sm text-gray-600 mb-2">수업 수</div>
            <div className="text-2xl text-gray-800">5개반</div>
          </div>
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <div className="text-sm text-gray-600 mb-2">학생 수</div>
            <div className="text-2xl text-gray-800">55명</div>
          </div>
        </div>

        {/* Work Days */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-4">
          <h2 className="text-lg text-gray-800 mb-4">근무 요일</h2>
          <div className="flex gap-2">
            {weekDays.map((day) => (
              <button
                key={day}
                className={`w-12 h-12 rounded-full ${
                  selectedWeekDays.includes(day)
                    ? 'bg-blue-100 text-blue-600'
                    : 'bg-gray-100 text-gray-400'
                }`}
              >
                {day}
              </button>
            ))}
          </div>
        </div>

        {/* Subjects */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-4">
          <h2 className="text-lg text-gray-800 mb-4">담당 과목</h2>
          <div className="flex flex-wrap gap-2">
            {subjects.map((subject) => (
              <span
                key={subject}
                className={`px-4 py-2 rounded-full text-sm ${subjectColors[subject]}`}
              >
                {subject}
              </span>
            ))}
          </div>
        </div>

        {/* Weekly Schedule */}
        <div className="bg-white rounded-lg border border-gray-200 p-6 mb-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <h2 className="text-lg text-gray-800">시간표</h2>
              <div className="flex gap-2">
                <button
                  onClick={() => setScheduleType('평일')}
                  className={`px-4 py-1 rounded text-sm transition-colors ${
                    scheduleType === '평일'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  평일
                </button>
                <button
                  onClick={() => setScheduleType('주말')}
                  className={`px-4 py-1 rounded text-sm transition-colors ${
                    scheduleType === '주말'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  주말
                </button>
              </div>
            </div>
            <button
              onClick={() => setIsClassRegisterModalOpen(true)}
              className="px-4 py-2 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 transition-colors"
            >
              수업 등록하기
            </button>
          </div>

          {/* Schedule Table */}
          {scheduleType === '평일' ? (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="border border-gray-200 bg-gray-50 p-3 text-sm text-gray-700 min-w-[80px]">
                      시간
                    </th>
                    {weekDays.map((day) => (
                      <th
                        key={day}
                        className="border border-gray-200 bg-gray-50 p-3 text-sm text-gray-700 min-w-[140px]"
                      >
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {timeSlots.map((time) => (
                    <tr key={time}>
                      <td className="border border-gray-200 p-3 text-sm text-gray-600 text-center bg-gray-50">
                        {time}
                      </td>
                      {weekDays.map((day) => {
                        const daySchedule = schedule[day as keyof typeof schedule] || [];
                        const classAtTime = daySchedule.find((item) => item.time === time);

                        return (
                          <td key={day} className="border border-gray-200 p-2">
                            {classAtTime && (
                              <div
                                className={`${classAtTime.color} border rounded p-2 text-xs relative cursor-pointer hover:shadow-md transition-shadow`}
                              >
                                <div className="flex items-start justify-between mb-1">
                                  <div className="flex-1">
                                    <div className="text-gray-800 mb-1">
                                      {classAtTime.title}
                                    </div>
                                    <div className="text-gray-600">{classAtTime.level}</div>
                                    <div className="text-gray-600">{classAtTime.room}</div>
                                  </div>
                                  <div className="flex gap-1">
                                    <button
                                      className="w-5 h-5 flex items-center justify-center bg-white rounded hover:bg-gray-100"
                                      onClick={() => {
                                        setSelectedClassInfo({
                                          title: classAtTime.title,
                                          time: time,
                                          room: classAtTime.room,
                                          teacher: teacherName,
                                          level: classAtTime.level
                                        });
                                        setIsClassStudentListModalOpen(true);
                                      }}
                                    >
                                      <Pencil className="w-3 h-3 text-gray-600" />
                                    </button>
                                    <button className="w-5 h-5 flex items-center justify-center bg-white rounded hover:bg-gray-100">
                                      <Edit className="w-3 h-3 text-gray-600" />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr>
                    <th className="border border-gray-200 bg-gray-50 p-3 text-sm text-gray-700 min-w-[80px]">
                      시간
                    </th>
                    {weekendDays.map((day) => (
                      <th
                        key={day}
                        className="border border-gray-200 bg-gray-50 p-3 text-sm text-gray-700 min-w-[140px]"
                      >
                        {day}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {weekendTimeSlots.map((time) => (
                    <tr key={time}>
                      <td className="border border-gray-200 p-3 text-sm text-gray-600 text-center bg-gray-50">
                        {time}
                      </td>
                      {weekendDays.map((day) => {
                        const daySchedule = weekendSchedule[day as keyof typeof weekendSchedule] || [];
                        const classAtTime = daySchedule.find((item) => item.time === time);

                        return (
                          <td key={day} className="border border-gray-200 p-2">
                            {classAtTime && (
                              <div
                                className={`${classAtTime.color} border rounded p-2 text-xs relative cursor-pointer hover:shadow-md transition-shadow`}
                              >
                                <div className="flex items-start justify-between mb-1">
                                  <div className="flex-1">
                                    <div className="text-gray-800 mb-1">
                                      {classAtTime.title}
                                    </div>
                                    <div className="text-gray-600">{classAtTime.level}</div>
                                    <div className="text-gray-600">{classAtTime.room}</div>
                                  </div>
                                  <div className="flex gap-1">
                                    <button
                                      className="w-5 h-5 flex items-center justify-center bg-white rounded hover:bg-gray-100"
                                      onClick={() => {
                                        setSelectedClassInfo({
                                          title: classAtTime.title,
                                          time: time,
                                          room: classAtTime.room,
                                          teacher: teacherName,
                                          level: classAtTime.level
                                        });
                                        setIsClassStudentListModalOpen(true);
                                      }}
                                    >
                                      <Pencil className="w-3 h-3 text-gray-600" />
                                    </button>
                                    <button className="w-5 h-5 flex items-center justify-center bg-white rounded hover:bg-gray-100">
                                      <Edit className="w-3 h-3 text-gray-600" />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            )}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Back Button */}
        <button
          onClick={onBack}
          className="w-full py-3 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors"
        >
          목록으로 돌아가기
        </button>

        {/* Modals */}
        <StudentRegisterModal
          isOpen={isStudentRegisterModalOpen}
          onClose={() => setIsStudentRegisterModalOpen(false)}
        />
        <TeacherRegisterModal
          isOpen={isTeacherRegisterModalOpen}
          onClose={() => setIsTeacherRegisterModalOpen(false)}
        />
        <ClassRegisterModal
          isOpen={isClassRegisterModalOpen}
          onClose={() => setIsClassRegisterModalOpen(false)}
          preSelectedTeacher={{
            id: '1',
            name: teacherName,
            workDays: selectedWeekDays,
            subjects: subjects
          }}
        />
        <ClassStudentListModal
          isOpen={isClassStudentListModalOpen}
          onClose={() => setIsClassStudentListModalOpen(false)}
          classInfo={selectedClassInfo}
        />
      </div>
    </div>
  );
}