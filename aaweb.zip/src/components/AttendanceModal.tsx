import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { useState } from 'react';

interface AttendanceModalProps {
  studentName: string;
  onClose: () => void;
}

export function AttendanceModal({ studentName, onClose }: AttendanceModalProps) {
  const [currentYear, setCurrentYear] = useState(2025);
  const [currentMonth, setCurrentMonth] = useState(4); // 5월 (0-indexed)
  const [attendanceData, setAttendanceData] = useState<{ [key: number]: string }>({});
  const [selectedDay, setSelectedDay] = useState<number | null>(null);
  const [showStatusMenu, setShowStatusMenu] = useState(false);

  const months = [
    '1월', '2월', '3월', '4월', '5월', '6월',
    '7월', '8월', '9월', '10월', '11월', '12월'
  ];

  // 달력 데이터 생성
  const getDaysInMonth = (year: number, month: number) => {
    return new Date(year, month + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (year: number, month: number) => {
    return new Date(year, month, 1).getDay();
  };

  const daysInMonth = getDaysInMonth(currentYear, currentMonth);
  const firstDay = getFirstDayOfMonth(currentYear, currentMonth);

  const getAttendanceIcon = (status: string) => {
    switch (status) {
      case 'present':
        return '😊';
      case 'absent':
        return '❌';
      case 'carryover':
        return '🔄';
      case 'late':
        return '⏰';
      case 'early':
        return '🏃';
      case 'sick':
        return '😷';
      case 'excused':
        return '📝';
      default:
        return '';
    }
  };

  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(currentYear - 1);
    } else {
      setCurrentMonth(currentMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(currentYear + 1);
    } else {
      setCurrentMonth(currentMonth + 1);
    }
  };

  const handleStatusChange = (status: string) => {
    if (selectedDay !== null) {
      setAttendanceData({
        ...attendanceData,
        [selectedDay]: status
      });
      setSelectedDay(null);
      setShowStatusMenu(false);
    }
  };

  const handleDeleteStatus = () => {
    if (selectedDay !== null) {
      const newData = { ...attendanceData };
      delete newData[selectedDay];
      setAttendanceData(newData);
      setSelectedDay(null);
      setShowStatusMenu(false);
    }
  };

  const handleDayClick = (day: number) => {
    setSelectedDay(day);
    setShowStatusMenu(true);
  };

  // 통계 계산
  const calculateStats = () => {
    const stats = {
      present: 0,
      absent: 0,
      late: 0,
      early: 0,
      sick: 0,
      excused: 0,
      carryover: 0,
    };

    Object.values(attendanceData).forEach((status) => {
      if (status === 'present') stats.present++;
      else if (status === 'absent') stats.absent++;
      else if (status === 'late') stats.late++;
      else if (status === 'early') stats.early++;
      else if (status === 'sick') stats.sick++;
      else if (status === 'excused') stats.excused++;
      else if (status === 'carryover') stats.carryover++;
    });

    return stats;
  };

  const stats = calculateStats();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-md">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-gray-800">조 {studentName}</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Month Selector */}
        <div className="p-4 flex items-center justify-between">
          <button
            onClick={handlePrevMonth}
            className="p-1 hover:bg-gray-100 rounded transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          </button>
          <div className="flex items-center gap-2">
            <span className="text-gray-700">{currentYear}년 {months[currentMonth]}</span>
            <button className="px-3 py-1 bg-blue-500 text-white text-sm rounded hover:bg-blue-600 transition-colors">
              오늘
            </button>
          </div>
          <button
            onClick={handleNextMonth}
            className="p-1 hover:bg-gray-100 rounded transition-colors"
          >
            <ChevronRight className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Stats */}
        <div className="px-4 pb-3 flex items-center justify-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <span className="text-blue-500">출석</span>
            <span className="text-gray-800">{stats.present}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-red-500">결석</span>
            <span className="text-gray-800">{stats.absent}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-yellow-500">지각</span>
            <span className="text-gray-800">{stats.late}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-orange-500">조퇴</span>
            <span className="text-gray-800">{stats.early}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-purple-500">병결</span>
            <span className="text-gray-800">{stats.sick}</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-green-500">공결</span>
            <span className="text-gray-800">{stats.excused}</span>
          </div>
        </div>

        {/* Calendar */}
        <div className="px-4 pb-4">
          {/* Day headers */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {['일', '월', '화', '수', '목', '금', '토'].map((day, index) => (
              <div
                key={day}
                className={`text-center text-xs py-1 ${
                  index === 0 ? 'text-red-500' : index === 6 ? 'text-blue-500' : 'text-gray-500'
                }`}
              >
                {day}
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1">
            {/* Empty cells before first day */}
            {Array.from({ length: firstDay }).map((_, index) => (
              <div key={`empty-${index}`} className="aspect-square" />
            ))}

            {/* Days */}
            {Array.from({ length: daysInMonth }).map((_, index) => {
              const day = index + 1;
              const dayOfWeek = (firstDay + index) % 7;
              const attendance = attendanceData[day];
              const today = new Date();
              const isToday = 
                day === today.getDate() && 
                currentMonth === today.getMonth() && 
                currentYear === today.getFullYear();

              return (
                <div
                  key={day}
                  className={`aspect-square flex flex-col items-center justify-center rounded border ${
                    isToday
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:bg-gray-50'
                  } transition-colors cursor-pointer`}
                  onClick={() => handleDayClick(day)}
                >
                  <span
                    className={`text-xs ${
                      dayOfWeek === 0
                        ? 'text-red-500'
                        : dayOfWeek === 6
                        ? 'text-blue-500'
                        : 'text-gray-700'
                    }`}
                  >
                    {day}
                  </span>
                  {attendance && (
                    <span className="text-lg">{getAttendanceIcon(attendance)}</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div className="px-4 pb-4 flex items-center justify-center gap-3 text-xs flex-wrap">
          <div className="flex items-center gap-1">
            <span>😊</span>
            <span className="text-gray-600">출석</span>
          </div>
          <div className="flex items-center gap-1">
            <span>❌</span>
            <span className="text-gray-600">결석</span>
          </div>
          <div className="flex items-center gap-1">
            <span>🔄</span>
            <span className="text-gray-600">연장</span>
          </div>
          <div className="flex items-center gap-1">
            <span>⏰</span>
            <span className="text-gray-600">지각</span>
          </div>
          <div className="flex items-center gap-1">
            <span>🏃</span>
            <span className="text-gray-600">조퇴</span>
          </div>
          <div className="flex items-center gap-1">
            <span>😷</span>
            <span className="text-gray-600">병결</span>
          </div>
          <div className="flex items-center gap-1">
            <span>📝</span>
            <span className="text-gray-600">공결</span>
          </div>
        </div>
      </div>

      {/* Status Selection Modal */}
      {showStatusMenu && selectedDay !== null && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-[60]">
          <div className="bg-white rounded-lg shadow-lg max-w-xs w-full mx-4">
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <h3 className="text-gray-800">{currentMonth + 1}월 {selectedDay}일 출석 상태</h3>
              <button
                onClick={() => {
                  setShowStatusMenu(false);
                  setSelectedDay(null);
                }}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4 grid grid-cols-2 gap-2">
              <button
                onClick={() => handleStatusChange('present')}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded hover:bg-blue-50 hover:border-blue-300 transition-colors"
              >
                <span className="text-2xl">😊</span>
                <span className="text-sm text-gray-700">출석</span>
              </button>
              <button
                onClick={() => handleStatusChange('absent')}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded hover:bg-red-50 hover:border-red-300 transition-colors"
              >
                <span className="text-2xl">❌</span>
                <span className="text-sm text-gray-700">결석</span>
              </button>
              <button
                onClick={() => handleStatusChange('carryover')}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded hover:bg-gray-50 hover:border-gray-300 transition-colors"
              >
                <span className="text-2xl">🔄</span>
                <span className="text-sm text-gray-700">이월</span>
              </button>
              <button
                onClick={() => handleStatusChange('late')}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded hover:bg-yellow-50 hover:border-yellow-300 transition-colors"
              >
                <span className="text-2xl">⏰</span>
                <span className="text-sm text-gray-700">지각</span>
              </button>
              <button
                onClick={() => handleStatusChange('early')}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded hover:bg-orange-50 hover:border-orange-300 transition-colors"
              >
                <span className="text-2xl">🏃</span>
                <span className="text-sm text-gray-700">조퇴</span>
              </button>
              <button
                onClick={() => handleStatusChange('sick')}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded hover:bg-purple-50 hover:border-purple-300 transition-colors"
              >
                <span className="text-2xl">😷</span>
                <span className="text-sm text-gray-700">병결</span>
              </button>
              <button
                onClick={() => handleStatusChange('excused')}
                className="flex items-center gap-2 p-3 border border-gray-200 rounded hover:bg-green-50 hover:border-green-300 transition-colors"
              >
                <span className="text-2xl">📝</span>
                <span className="text-sm text-gray-700">공결</span>
              </button>
              {attendanceData[selectedDay] && (
                <button
                  onClick={handleDeleteStatus}
                  className="flex items-center justify-center p-3 border border-red-200 rounded hover:bg-red-50 hover:border-red-300 transition-colors"
                >
                  <span className="text-sm text-red-600">내용 삭제</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}