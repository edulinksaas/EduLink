
  # 에듀링크 웹

  This is a code bundle for 에듀링크 웹. The original project is available at https://www.figma.com/design/amQp0BQxrAg9MDuEeal8qO/%EC%97%90%EB%93%80%EB%A7%81%ED%81%AC-%EC%9B%B9.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  