import svgPaths from "./svg-nm5t0z9i0w";
import clsx from "clsx";
type Button10Props = {
  additionalClassNames?: string;
};

function Button10({ children, additionalClassNames = "" }: React.PropsWithChildren<Button10Props>) {
  return (
    <div className={clsx("relative shrink-0", additionalClassNames)}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">{children}</div>
    </div>
  );
}

function Text13({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="basis-0 grow h-[24px] min-h-px min-w-px relative shrink-0">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">{children}</div>
    </div>
  );
}
type Wrapper3Props = {
  additionalClassNames?: string;
};

function Wrapper3({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper3Props>) {
  return (
    <div className={clsx("relative rounded-[4px] shrink-0", additionalClassNames)}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">{children}</div>
    </div>
  );
}
type Wrapper2Props = {
  additionalClassNames?: string;
};

function Wrapper2({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper2Props>) {
  return (
    <div className={additionalClassNames}>
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-start relative size-full">{children}</div>
    </div>
  );
}
type Wrapper1Props = {
  additionalClassNames?: string;
};

function Wrapper1({ children, additionalClassNames = "" }: React.PropsWithChildren<Wrapper1Props>) {
  return <Wrapper2 additionalClassNames={clsx("h-[15.986px] relative shrink-0", additionalClassNames)}>{children}</Wrapper2>;
}

function Wrapper({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 size-[20px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        {children}
      </svg>
    </div>
  );
}

function Icon11({ children }: React.PropsWithChildren<{}>) {
  return (
    <div className="relative shrink-0 size-[32px]">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">{children}</g>
      </svg>
    </div>
  );
}

function Icon10({ children }: React.PropsWithChildren<{}>) {
  return (
    <Wrapper>
      <g id="Icon">{children}</g>
    </Wrapper>
  );
}
type ContainerText1Props = {
  text: string;
};

function ContainerText1({ text }: ContainerText1Props) {
  return (
    <div className="content-stretch flex h-[15.986px] items-start relative shrink-0 w-full">
      <p className="basis-0 font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px not-italic relative shrink-0 text-[#4a5565] text-[7.5px]">{text}</p>
    </div>
  );
}
type TextText1Props = {
  text: string;
  additionalClassNames?: string;
};

function TextText1({ text, additionalClassNames = "" }: TextText1Props) {
  return (
    <Wrapper2 additionalClassNames={clsx("h-[20px] relative shrink-0", additionalClassNames)}>
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[20px] not-italic relative shrink-0 text-[#4a5565] text-[14px] text-center text-nowrap">{text}</p>
    </Wrapper2>
  );
}
type TextTextProps = {
  text: string;
};

function TextText({ text }: TextTextProps) {
  return (
    <div className="content-stretch flex h-[18.667px] items-start relative shrink-0 w-full">
      <p className="basis-0 font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[#364153] text-[14px] text-center">{text}</p>
    </div>
  );
}
type ButtonTextProps = {
  text: string;
};

function ButtonText({ text }: ButtonTextProps) {
  return (
    <div className="bg-white relative rounded-[4px] shrink-0 size-[40px]">
      <div aria-hidden="true" className="absolute border-[#d1d5dc] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center p-[0.889px] relative size-full">
        <p className="font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[#364153] text-[16px] text-center text-nowrap">{text}</p>
      </div>
    </div>
  );
}
type LinkTextProps = {
  text: string;
  additionalClassNames?: string;
};

function LinkText({ text, additionalClassNames = "" }: LinkTextProps) {
  return (
    <div className={clsx("absolute content-stretch flex h-[18.667px] items-start top-[147.56px]", additionalClassNames)}>
      <p className="basis-0 font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[#2b7fff] text-[14px] text-center">{text}</p>
    </div>
  );
}
type ContainerTextProps = {
  text: string;
  additionalClassNames?: string;
};

function ContainerText({ text, additionalClassNames = "" }: ContainerTextProps) {
  return (
    <div className={clsx("absolute content-stretch flex h-[20px] items-start left-[24px] top-[24px]", additionalClassNames)}>
      <p className="basis-0 font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal grow leading-[20px] min-h-px min-w-px not-italic relative shrink-0 text-[#4a5565] text-[14px] text-center">{text}</p>
    </div>
  );
}
type IconVectorProps = {
  additionalClassNames?: string;
};

function IconVector({ additionalClassNames = "" }: IconVectorProps) {
  return (
    <div className={clsx("absolute left-[16.67%] right-[16.67%]", additionalClassNames)}>
      <div className="absolute inset-[-0.83px_-6.25%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 1.66667">
          <path d="M0.833333 0.833333H14.1667" id="Vector" stroke="var(--stroke-0, #0A0A0A)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </svg>
      </div>
    </div>
  );
}

function Icon() {
  return (
    <div className="h-[20px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <IconVector additionalClassNames="bottom-1/2 top-1/2" />
      <IconVector additionalClassNames="bottom-3/4 top-1/4" />
      <IconVector additionalClassNames="bottom-1/4 top-3/4" />
    </div>
  );
}

function Button() {
  return (
    <div className="relative rounded-[4px] shrink-0 size-[36px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start pb-0 pt-[8px] px-[8px] relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Text() {
  return (
    <Wrapper1 additionalClassNames="w-[12px]">
      <p className="font-['Inter:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[7.5px] text-center text-nowrap text-white">img</p>
    </Wrapper1>
  );
}

function Container() {
  return (
    <Wrapper3 additionalClassNames="bg-[#314158] size-[24px]">
      <Text />
    </Wrapper3>
  );
}

function Text1() {
  return (
    <Text13>
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[24px] left-[40.5px] not-italic text-[#1e2939] text-[16px] text-center text-nowrap top-[-2.11px] translate-x-[-50%]">학원 명</p>
    </Text13>
  );
}

function Button1() {
  return (
    <div className="basis-0 grow h-[24px] min-h-px min-w-px relative shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center relative size-full">
        <Container />
        <Text1 />
      </div>
    </div>
  );
}

function Container1() {
  return (
    <div className="h-[36px] relative shrink-0 w-[160px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[12px] items-center relative size-full">
        <Button />
        <Button1 />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <Wrapper>
      <g clipPath="url(#clip0_29_2405)" id="Icon">
        <path d={svgPaths.p14d24500} id="Vector" stroke="var(--stroke-0, #2B7FFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        <path d={svgPaths.p2e4e0200} id="Vector_2" stroke="var(--stroke-0, #2B7FFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        <path d="M10 14.1667H10.0083" id="Vector_3" stroke="var(--stroke-0, #2B7FFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
      </g>
      <defs>
        <clipPath id="clip0_29_2405">
          <rect fill="white" height="20" width="20" />
        </clipPath>
      </defs>
    </Wrapper>
  );
}

function Text2() {
  return (
    <Wrapper1 additionalClassNames="w-[36px]">
      <p className="basis-0 font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px not-italic relative shrink-0 text-[#2b7fff] text-[12px] text-center">사용법</p>
    </Wrapper1>
  );
}

function Button2() {
  return (
    <div className="h-[39.986px] relative shrink-0 w-[36px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-center relative size-full">
        <Icon1 />
        <Text2 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <Icon10>
      <path d={svgPaths.p15ab6200} id="Vector" stroke="var(--stroke-0, #6A7282)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
      <path d={svgPaths.p3b27f100} id="Vector_2" stroke="var(--stroke-0, #6A7282)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
    </Icon10>
  );
}

function Text3() {
  return (
    <Wrapper1 additionalClassNames="w-[24px]">
      <p className="font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[16px] not-italic relative shrink-0 text-[#6a7282] text-[12px] text-center text-nowrap">설정</p>
    </Wrapper1>
  );
}

function Button3() {
  return (
    <div className="h-[39.986px] relative shrink-0 w-[24px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-center relative size-full">
        <Icon2 />
        <Text3 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <Icon10>
      <path d={svgPaths.p38966ca0} id="Vector" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
      <path d={svgPaths.p14ca9100} id="Vector_2" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
      <path d="M17.5 10H7.5" id="Vector_3" stroke="var(--stroke-0, #FF8904)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
    </Icon10>
  );
}

function Text4() {
  return (
    <Wrapper1 additionalClassNames="w-[48px]">
      <p className="basis-0 font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal grow leading-[16px] min-h-px min-w-px not-italic relative shrink-0 text-[#ff8904] text-[12px] text-center">로그아웃</p>
    </Wrapper1>
  );
}

function Button4() {
  return (
    <div className="basis-0 grow h-[39.986px] min-h-px min-w-px relative shrink-0" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-center relative size-full">
        <Icon3 />
        <Text4 />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="h-[39.986px] relative shrink-0 w-[140px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[16px] items-center relative size-full">
        <Button2 />
        <Button3 />
        <Button4 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex h-[39.986px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Container1 />
      <Container2 />
    </div>
  );
}

function Header() {
  return (
    <div className="bg-white content-stretch flex flex-col h-[64.875px] items-start pb-[0.889px] pt-[12px] px-[16px] relative shrink-0 w-[1319.111px]" data-name="Header">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container3 />
    </div>
  );
}

function Icon4() {
  return (
    <Icon11>
      <path d={svgPaths.p25024900} id="Vector" stroke="var(--stroke-0, #2B7FFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
      <path d={svgPaths.p230c5e00} id="Vector_2" stroke="var(--stroke-0, #2B7FFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
      <path d="M8 16H8.01333M24 16H24.0133" id="Vector_3" stroke="var(--stroke-0, #2B7FFF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
    </Icon11>
  );
}

function Container4() {
  return (
    <div className="absolute content-stretch flex h-[32px] items-start justify-center left-[24px] top-[56px] w-[368.583px]" data-name="Container">
      <Icon4 />
    </div>
  );
}

function Text5() {
  return (
    <div className="h-[36px] relative shrink-0 w-[151.708px]" data-name="Text">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[36px] left-[76px] not-italic text-[#1e2939] text-[30px] text-center text-nowrap top-[-3.67px] translate-x-[-50%]">₩8,830,000</p>
      </div>
    </div>
  );
}

function Text6() {
  return <div className="shrink-0 size-0" data-name="Text" />;
}

function Container5() {
  return (
    <div className="absolute content-stretch flex h-[36px] items-center justify-center left-[24px] pl-0 pr-[0.014px] py-0 top-[100px] w-[368.583px]" data-name="Container">
      <Text5 />
      <Text6 />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute bg-white border-[#e5e7eb] border-[0.889px] border-solid h-[193.778px] left-0 rounded-[10px] top-0 w-[418.361px]" data-name="Container">
      <ContainerText text="금일 현황" additionalClassNames="w-[368.583px]" />
      <Container4 />
      <Container5 />
      <LinkText text="자세 보기 →" additionalClassNames="left-[168.71px] w-[79.153px]" />
    </div>
  );
}

function Icon5() {
  return (
    <Icon11>
      <path d={svgPaths.p27a3200} id="Vector" stroke="var(--stroke-0, #00C950)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
      <path d={svgPaths.p2ee517c0} id="Vector_2" stroke="var(--stroke-0, #00C950)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
      <path d={svgPaths.p18f42980} id="Vector_3" stroke="var(--stroke-0, #00C950)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
      <path d={svgPaths.p1eb5fb00} id="Vector_4" stroke="var(--stroke-0, #00C950)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
    </Icon11>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex h-[32px] items-start justify-center left-[24px] pl-0 pr-[0.014px] py-0 top-[56px] w-[368.597px]" data-name="Container">
      <Icon5 />
    </div>
  );
}

function Text7() {
  return (
    <div className="absolute h-[36px] left-[150.5px] top-0 w-[49.583px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[36px] left-[25.5px] not-italic text-[#1e2939] text-[30px] text-center text-nowrap top-[-3.67px] translate-x-[-50%]">125</p>
    </div>
  );
}

function Text8() {
  return (
    <div className="absolute h-[28px] left-[200.08px] top-[4px] w-[18px]" data-name="Text">
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[28px] left-[9.5px] not-italic text-[#1e2939] text-[18px] text-center text-nowrap top-[-1.22px] translate-x-[-50%]">명</p>
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute h-[36px] left-[24px] top-[100px] w-[368.597px]" data-name="Container">
      <Text7 />
      <Text8 />
    </div>
  );
}

function Container9() {
  return (
    <div className="absolute bg-white border-[#e5e7eb] border-[0.889px] border-solid h-[193.778px] left-[434.36px] rounded-[10px] top-0 w-[418.375px]" data-name="Container">
      <ContainerText text="전체 학생" additionalClassNames="w-[368.597px]" />
      <Container7 />
      <Container8 />
      <LinkText text="자세히 보기 →" additionalClassNames="left-[161.72px] w-[93.153px]" />
    </div>
  );
}

function Icon6() {
  return (
    <Icon11>
      <path d={svgPaths.pac92380} id="Vector" stroke="var(--stroke-0, #AD46FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
      <path d="M29.3333 13.3333V21.3333" id="Vector_2" stroke="var(--stroke-0, #AD46FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
      <path d={svgPaths.p3858b240} id="Vector_3" stroke="var(--stroke-0, #AD46FF)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.66667" />
    </Icon11>
  );
}

function Container10() {
  return (
    <div className="absolute content-stretch flex h-[32px] items-start justify-center left-[24px] top-[56px] w-[368.583px]" data-name="Container">
      <Icon6 />
    </div>
  );
}

function Text9() {
  return (
    <div className="absolute h-[36px] left-[176.03px] top-0 w-[16.528px]" data-name="Text">
      <p className="absolute font-['Inter:Regular',sans-serif] font-normal leading-[36px] left-[8.5px] not-italic text-[#1e2939] text-[30px] text-center text-nowrap top-[-3.67px] translate-x-[-50%]">8</p>
    </div>
  );
}

function Text10() {
  return <div className="absolute left-[192.56px] size-0 top-[18px]" data-name="Text" />;
}

function Container11() {
  return (
    <div className="absolute h-[36px] left-[24px] top-[100px] w-[368.583px]" data-name="Container">
      <Text9 />
      <Text10 />
    </div>
  );
}

function Container12() {
  return (
    <div className="absolute bg-white border-[#e5e7eb] border-[0.889px] border-solid h-[193.778px] left-[868.74px] rounded-[10px] top-0 w-[418.361px]" data-name="Container">
      <ContainerText text="전체 선생님" additionalClassNames="w-[368.583px]" />
      <Container10 />
      <Container11 />
      <LinkText text="자세히 보기 →" additionalClassNames="left-[161.71px] w-[93.153px]" />
    </div>
  );
}

function Container13() {
  return (
    <div className="h-[193.778px] relative shrink-0 w-full" data-name="Container">
      <Container6 />
      <Container9 />
      <Container12 />
    </div>
  );
}

function Heading() {
  return <div className="h-[24px] shrink-0 w-[32px]" data-name="Heading 2" />;
}

function Container14() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Heading />
    </div>
  );
}

function Section() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[194px] items-start relative shrink-0 w-full" data-name="Section">
      <Container13 />
      <Container14 />
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[24px] relative shrink-0 w-[85.625px]" data-name="Heading 2">
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[24px] left-0 not-italic text-[#1e2939] text-[16px] text-nowrap top-[-2.11px]">전체 시간표</p>
    </div>
  );
}

function Button5() {
  return (
    <div className="bg-[#2b7fff] content-stretch flex h-[40px] items-center justify-center relative rounded-[4px] shrink-0 w-[60px]" data-name="Button">
      <p className="font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[16px] text-center text-nowrap text-white">구역 1</p>
    </div>
  );
}

function Button6() {
  return (
    <div className="bg-white content-stretch flex h-[40px] items-center justify-center p-[0.889px] relative rounded-[4px] shrink-0 w-[60px]" data-name="Button">
      <div aria-hidden="true" className="absolute border-[#d1d5dc] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <p className="font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[#364153] text-[16px] text-center text-nowrap">구역 2</p>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex gap-[10px] items-center justify-center relative shrink-0 w-[154px]">
      <Button5 />
      <Button6 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="relative shrink-0 w-[250px]">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[10px] items-center relative w-full">
        <Heading1 />
        <Frame />
      </div>
    </div>
  );
}

function Button7() {
  return (
    <Wrapper3 additionalClassNames="bg-[#2b7fff] size-[40px]">
      <p className="font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[24px] not-italic relative shrink-0 text-[16px] text-center text-nowrap text-white">월</p>
    </Wrapper3>
  );
}

function Icon7() {
  return (
    <div className="relative shrink-0 size-[16px]" data-name="Icon">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 16">
        <g id="Icon">
          <path d="M3.33333 8H12.6667" id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          <path d="M8 3.33333V12.6667" id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
        </g>
      </svg>
    </div>
  );
}

function Text11() {
  return (
    <Text13>
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[24px] left-[35px] not-italic text-[16px] text-center text-nowrap text-white top-[-2.11px] translate-x-[-50%]">등록 하기</p>
    </Text13>
  );
}

function Component() {
  return (
    <div className="bg-[#2b7fff] h-[40px] relative rounded-[4px] shrink-0 w-[125.625px]" data-name="등록하기">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-center justify-end px-[16px] py-0 relative size-full">
        <Icon7 />
        <Text11 />
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[40px] relative shrink-0 w-[328px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[8px] items-start relative size-full">
        <Button7 />
        <ButtonText text="화" />
        <ButtonText text="수" />
        <ButtonText text="목" />
        <ButtonText text="금" />
        <ButtonText text="토" />
        <ButtonText text="일" />
        <Component />
      </div>
    </div>
  );
}

function Container16() {
  return (
    <div className="content-stretch flex h-[40px] items-center justify-between relative shrink-0 w-[1151px]" data-name="Container">
      <Frame1 />
      <Container15 />
    </div>
  );
}

function Container17() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex flex-col h-[48px] items-start left-0 pb-0 pl-[92.667px] pr-[93.556px] pt-[15.556px] top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText text="시간" />
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[48px] items-start left-[214.22px] pb-0 pl-[85.667px] pr-[86.556px] pt-[15.556px] top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText text="축구장" />
    </div>
  );
}

function Container19() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[48px] items-start left-[428.44px] pb-0 pl-[85.667px] pr-[86.556px] pt-[15.556px] top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText text="농구장" />
    </div>
  );
}

function Container20() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[48px] items-start left-[642.67px] pb-0 pl-[71.667px] pr-[72.556px] pt-[15.556px] top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText text="배드민턴장" />
    </div>
  );
}

function Container21() {
  return (
    <div className="absolute bg-white content-stretch flex flex-col h-[48px] items-start left-[856.89px] pb-0 pl-[85.667px] pr-[86.556px] pt-[15.556px] top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText text="발레실" />
    </div>
  );
}

function Text12() {
  return (
    <div className="absolute bg-white h-[48px] left-[1071.11px] top-0 w-[214.222px]" data-name="Text">
      <p className="absolute font-['Inter:Regular','Noto_Sans_KR:Regular',sans-serif] font-normal leading-[20px] left-[107.61px] not-italic text-[#364153] text-[14px] text-center text-nowrap top-[13.56px] translate-x-[-50%]">댄스실</p>
    </div>
  );
}

function Container22() {
  return (
    <div className="h-[48.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container17 />
      <Container18 />
      <Container19 />
      <Container20 />
      <Container21 />
      <Text12 />
    </div>
  );
}

function Container23() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.903px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="9:00" additionalClassNames="w-[26.208px]" />
    </div>
  );
}

function Container24() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container25() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container26() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container27() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container28() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container29() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container23 />
      <Container24 />
      <Container25 />
      <Container26 />
      <Container27 />
      <Container28 />
    </div>
  );
}

function Container30() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="10:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container31() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container32() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container33() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container34() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container35() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container36() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container30 />
      <Container31 />
      <Container32 />
      <Container33 />
      <Container34 />
      <Container35 />
    </div>
  );
}

function Container37() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="11:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container38() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container39() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container40() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container41() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container42() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container43() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container37 />
      <Container38 />
      <Container39 />
      <Container40 />
      <Container41 />
      <Container42 />
    </div>
  );
}

function Container44() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[77.736px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="12:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container45() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[77.736px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container46() {
  return (
    <div className="content-stretch flex h-[15.986px] items-start relative shrink-0 w-full" data-name="Container">
      <p className="basis-0 font-['Acme:Regular','Noto_Sans_KR:Regular',sans-serif] grow leading-[16px] min-h-px min-w-px relative shrink-0 text-[#1e2939] text-[12px]" style={{ fontVariationSettings: "'wght' 400" }}>
        반 이름
      </p>
    </div>
  );
}

function Container47() {
  return (
    <div className="basis-0 grow h-[51.958px] min-h-px min-w-px relative shrink-0" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col gap-[4px] items-start relative size-full">
        <Container46 />
        <ContainerText1 text="담당 선생님 : 이름" />
        <ContainerText1 text="학생 수 : 현재 인원 / 전체 인원" />
      </div>
    </div>
  );
}

function Icon8() {
  return (
    <div className="h-[12px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[16.67%]" data-name="Vector">
        <div className="absolute inset-[-9.38%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 9.5 9.5">
            <path d={svgPaths.pdd30900} id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeWidth="1.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Button8() {
  return (
    <Button10 additionalClassNames="size-[12px]">
      <Icon8 />
    </Button10>
  );
}

function Icon9() {
  return (
    <div className="h-[12px] overflow-clip relative shrink-0 w-full" data-name="Icon">
      <div className="absolute inset-[16.67%]" data-name="Vector">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d="M4 0V8M0 4H8" id="Vector" stroke="var(--stroke-0, #99A1AF)" strokeWidth="1.5" />
        </svg>
      </div>
    </div>
  );
}

function Button9() {
  return (
    <Button10 additionalClassNames="h-full w-[12px]">
      <Icon9 />
    </Button10>
  );
}

function Container48() {
  return (
    <div className="h-[12px] relative shrink-0 w-[28px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex gap-[4px] items-start relative size-full">
        <Button8 />
        <Button9 />
      </div>
    </div>
  );
}

function Container49() {
  return (
    <div className="h-[51.958px] relative shrink-0 w-full" data-name="Container">
      <div className="size-full">
        <div className="content-stretch flex items-start justify-between relative size-full">
          <Container47 />
          <Container48 />
        </div>
      </div>
    </div>
  );
}

function Container50() {
  return (
    <div className="bg-[#fce7f3] h-[69.736px] relative rounded-[4px] shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#fda5d5] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[4px]" />
      <div className="size-full">
        <div className="content-stretch flex flex-col items-start pb-[0.889px] pt-[8.889px] px-[8.889px] relative size-full">
          <Container49 />
        </div>
      </div>
    </div>
  );
}

function Container51() {
  return (
    <div className="absolute content-stretch flex flex-col h-[77.736px] items-start left-[428.44px] pb-0 pl-[4px] pr-[4.889px] pt-[4px] top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <Container50 />
    </div>
  );
}

function Container52() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[77.736px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container53() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[77.736px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container54() {
  return <div className="absolute h-[77.736px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container55() {
  return (
    <div className="h-[78.625px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container44 />
      <Container45 />
      <Container51 />
      <Container52 />
      <Container53 />
      <Container54 />
    </div>
  );
}

function Container56() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="13:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container57() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container58() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container59() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container60() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container61() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container62() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container56 />
      <Container57 />
      <Container58 />
      <Container59 />
      <Container60 />
      <Container61 />
    </div>
  );
}

function Container63() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="14:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container64() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container65() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container66() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container67() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container68() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container69() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container63 />
      <Container64 />
      <Container65 />
      <Container66 />
      <Container67 />
      <Container68 />
    </div>
  );
}

function Container70() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="15:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container71() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container72() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container73() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container74() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container75() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container76() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container70 />
      <Container71 />
      <Container72 />
      <Container73 />
      <Container74 />
      <Container75 />
    </div>
  );
}

function Container77() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="16:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container78() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container79() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container80() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container81() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container82() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container83() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container77 />
      <Container78 />
      <Container79 />
      <Container80 />
      <Container81 />
      <Container82 />
    </div>
  );
}

function Container84() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="17:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container85() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container86() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container87() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container88() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container89() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container90() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container84 />
      <Container85 />
      <Container86 />
      <Container87 />
      <Container88 />
      <Container89 />
    </div>
  );
}

function Container91() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="18:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container92() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container93() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container94() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container95() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container96() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container97() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container91 />
      <Container92 />
      <Container93 />
      <Container94 />
      <Container95 />
      <Container96 />
    </div>
  );
}

function Container98() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="19:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container99() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container100() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container101() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container102() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container103() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container104() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container98 />
      <Container99 />
      <Container100 />
      <Container101 />
      <Container102 />
      <Container103 />
    </div>
  );
}

function Container105() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[128px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="20:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container106() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[128px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container107() {
  return (
    <div className="absolute h-[128px] left-[428.44px] top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
    </div>
  );
}

function Container108() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[128px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container109() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[128px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container110() {
  return <div className="absolute h-[128px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container111() {
  return (
    <div className="h-[128.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container105 />
      <Container106 />
      <Container107 />
      <Container108 />
      <Container109 />
      <Container110 />
    </div>
  );
}

function Container112() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="21:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container113() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container114() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container115() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container116() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container117() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container118() {
  return (
    <div className="h-[60.889px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0px_0.889px] border-solid inset-0 pointer-events-none" />
      <Container112 />
      <Container113 />
      <Container114 />
      <Container115 />
      <Container116 />
      <Container117 />
    </div>
  );
}

function Container119() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex h-[60px] items-center justify-center left-0 pl-0 pr-[0.889px] py-0 top-0 w-[214.222px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid inset-0 pointer-events-none" />
      <TextText1 text="22:00" additionalClassNames="w-[33.917px]" />
    </div>
  );
}

function Container120() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[214.22px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container121() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[428.44px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container122() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[642.67px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container123() {
  return <div className="absolute border-[#e5e7eb] border-[0px_0.889px_0px_0px] border-solid h-[60px] left-[856.89px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container124() {
  return <div className="absolute h-[60px] left-[1071.11px] top-0 w-[214.222px]" data-name="Container" />;
}

function Container125() {
  return (
    <div className="h-[60px] relative shrink-0 w-full" data-name="Container">
      <Container119 />
      <Container120 />
      <Container121 />
      <Container122 />
      <Container123 />
      <Container124 />
    </div>
  );
}

function Container126() {
  return (
    <div className="content-stretch flex flex-col h-[986.181px] items-start relative shrink-0 w-full" data-name="Container">
      <Container22 />
      <Container29 />
      <Container36 />
      <Container43 />
      <Container55 />
      <Container62 />
      <Container69 />
      <Container76 />
      <Container83 />
      <Container90 />
      <Container97 />
      <Container104 />
      <Container111 />
      <Container118 />
      <Container125 />
    </div>
  );
}

function Container127() {
  return (
    <div className="bg-white h-[987.958px] relative rounded-[10px] shrink-0 w-full" data-name="Container">
      <div className="overflow-clip rounded-[inherit] size-full">
        <div className="content-stretch flex flex-col items-start p-[0.889px] relative size-full">
          <Container126 />
        </div>
      </div>
      <div aria-hidden="true" className="absolute border-[#e5e7eb] border-[0.889px] border-solid inset-0 pointer-events-none rounded-[10px]" />
    </div>
  );
}

function Section1() {
  return (
    <div className="content-stretch flex flex-col gap-[16px] h-[1043.958px] items-start relative shrink-0 w-full" data-name="Section">
      <Container16 />
      <Container127 />
    </div>
  );
}

function MainContent() {
  return (
    <div className="h-[1349.736px] relative shrink-0 w-full" data-name="Main Content">
      <div className="size-full">
        <div className="content-stretch flex flex-col gap-[24px] items-start pb-0 pt-[16px] px-[16px] relative size-full">
          <Section />
          <Section1 />
        </div>
      </div>
    </div>
  );
}

function Component1() {
  return (
    <div className="absolute bg-[#f9fafb] content-stretch flex flex-col h-[1414.611px] items-start left-0 top-0 w-[1319.111px]" data-name="홈 화면">
      <Header />
      <MainContent />
    </div>
  );
}

export default function Component2() {
  return (
    <div className="bg-white relative size-full" data-name="홈 화면">
      <Component1 />
    </div>
  );
}