import { Search, ChevronDown, Plus, Edit, Trash2, ChevronLeft, ChevronRight, Calendar, GraduationCap, Users } from 'lucide-react';
import { useState } from 'react';
import { StudentDetailPage } from './StudentDetailPage';

interface AllStudentsProps {
  onBack: () => void;
  onStudentClick?: (studentId: number) => void;
  onRegisterClick?: () => void;
}

export function AllStudents({ onBack, onStudentClick, onRegisterClick }: AllStudentsProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('전체');
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedStudent, setSelectedStudent] = useState<string | null>(null);
  const itemsPerPage = 10;

  const filterOptions = ['전체', '이름', '학년반', '과목'];

  const students = [
    {
      id: 1,
      category: '신규',
      name: '김민수',
      grade: '초등학교 5학년',
      subject: '수학',
      lesson: '기초수학',
      teacher: '김민지',
      phone: '010-1234-5678',
      time: '14:00-15:00',
      startDate: '2025-01-15',
      fee: '150,000',
      receipt: true,
      paymentDate: '매월 1일',
      note: ''
    },
    {
      id: 2,
      category: '재원',
      name: '이서연',
      grade: '중등학교 2학년',
      subject: '영어',
      lesson: '문법 기초',
      teacher: '이수진',
      phone: '010-2345-6789',
      time: '15:00-16:00',
      startDate: '2024-12-20',
      fee: '180,000',
      receipt: false,
      paymentDate: '매월 1일',
      note: ''
    },
    {
      id: 3,
      category: '재원',
      name: '박지훈',
      grade: '고등학교 1학년',
      subject: '수학',
      lesson: '고급 수학',
      teacher: '김민지',
      phone: '010-3456-7890',
      time: '16:00-17:00',
      startDate: '2024-11-01',
      fee: '200,000',
      receipt: true,
      paymentDate: '매월 5일',
      note: ''
    },
    {
      id: 4,
      category: '신규',
      name: '최유진',
      grade: '초등학교 6학년',
      subject: '국어',
      lesson: '독해 연습',
      teacher: '박성호',
      phone: '010-4567-8901',
      time: '13:00-14:00',
      startDate: '2025-01-10',
      fee: '140,000',
      receipt: true,
      paymentDate: '매월 1일',
      note: ''
    },
    {
      id: 5,
      category: '재원',
      name: '정하늘',
      grade: '중등학교 3학년',
      subject: '과학',
      lesson: '물리 기초',
      teacher: '이수진',
      phone: '010-5678-9012',
      time: '17:00-18:00',
      startDate: '2024-10-15',
      fee: '190,000',
      receipt: false,
      paymentDate: '매월 10일',
      note: ''
    },
    {
      id: 6,
      category: '신규',
      name: '강민지',
      grade: '초등학교 4학년',
      subject: '영어',
      lesson: '기초 회화',
      teacher: '박성호',
      phone: '010-6789-0123',
      time: '14:00-15:00',
      startDate: '2025-01-25',
      fee: '160,000',
      receipt: true,
      paymentDate: '매월 1일',
      note: ''
    },
    {
      id: 7,
      category: '재원',
      name: '윤서준',
      grade: '고등학교 2학년',
      subject: '수학',
      lesson: '미적분',
      teacher: '김민지',
      phone: '010-7890-1234',
      time: '18:00-19:00',
      startDate: '2024-09-05',
      fee: '220,000',
      receipt: true,
      paymentDate: '매월 5일',
      note: ''
    },
    {
      id: 8,
      category: '재원',
      name: '임채원',
      grade: '중등학교 1학년',
      subject: '국어',
      lesson: '문학 이해',
      teacher: '박성호',
      phone: '010-8901-2345',
      time: '15:00-16:00',
      startDate: '2024-08-20',
      fee: '170,000',
      receipt: false,
      paymentDate: '매월 1일',
      note: ''
    },
    {
      id: 9,
      category: '신규',
      name: '한지민',
      grade: '초등학교 3학년',
      subject: '수학',
      lesson: '기초 연산',
      teacher: '김민지',
      phone: '010-9012-3456',
      time: '13:00-14:00',
      startDate: '2025-01-05',
      fee: '130,000',
      receipt: true,
      paymentDate: '매월 1일',
      note: ''
    },
    {
      id: 10,
      category: '재원',
      name: '송하윤',
      grade: '고등학교 3학년',
      subject: '영어',
      lesson: '수능 영어',
      teacher: '이수진',
      phone: '010-0123-4567',
      time: '19:00-20:00',
      startDate: '2024-07-01',
      fee: '250,000',
      receipt: true,
      paymentDate: '매월 10일',
      note: ''
    },
    {
      id: 11,
      category: '신규',
      name: '배준호',
      grade: '중등학교 2학년',
      subject: '과학',
      lesson: '화학 기초',
      teacher: '박성호',
      phone: '010-1111-2222',
      time: '16:00-17:00',
      startDate: '2025-01-20',
      fee: '175,000',
      receipt: false,
      paymentDate: '매월 1일',
      note: ''
    },
    {
      id: 12,
      category: '재원',
      name: '조윤서',
      grade: '초등학교 6학년',
      subject: '수학',
      lesson: '심화 수학',
      teacher: '김민지',
      phone: '010-2222-3333',
      time: '14:00-15:00',
      startDate: '2024-06-15',
      fee: '155,000',
      receipt: true,
      paymentDate: '매월 5일',
      note: ''
    }
  ];

  // 전체 학생 수 계산
  const totalStudents = students.length;

  // 월 신규 인원 수 계산 (현재 월: 2025년 1월)
  const currentMonth = '2025-01';
  const monthlyNewStudents = students.filter(student => 
    student.category === '신규' && student.startDate.startsWith(currentMonth)
  ).length;

  const filteredStudents = students.filter(student => {
    if (!searchTerm) return true;
    
    switch (filterType) {
      case '이름':
        return student.name.toLowerCase().includes(searchTerm.toLowerCase());
      case '학년반':
        return student.grade.toLowerCase().includes(searchTerm.toLowerCase());
      case '과목':
        return student.subject.toLowerCase().includes(searchTerm.toLowerCase());
      default:
        return (
          student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student.grade.toLowerCase().includes(searchTerm.toLowerCase()) ||
          student.subject.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
  });

  const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const paginatedStudents = filteredStudents.slice(startIndex, startIndex + itemsPerPage);

  // If a student is selected, show the detail page
  if (selectedStudent) {
    return (
      <StudentDetailPage 
        studentName={selectedStudent} 
        onBack={() => setSelectedStudent(null)} 
      />
    );
  }

  return (
    <div>
      {/* Title */}
      <div className="mb-6">
        <h1 className="text-2xl text-gray-800">전체 학생</h1>
      </div>

      {/* Search Section */}
      <div className="mb-6 flex items-center gap-3">
        <div className="relative">
          <button
            className="h-[42px] px-4 py-2 border border-gray-300 rounded bg-white text-gray-700 flex items-center gap-2 min-w-[120px]"
            onClick={() => setIsFilterOpen(!isFilterOpen)}
          >
            <span>{filterType}</span>
            <ChevronDown className="w-4 h-4" />
          </button>
          {isFilterOpen && (
            <>
              <div 
                className="fixed inset-0 z-10"
                onClick={() => setIsFilterOpen(false)}
              />
              <div className="absolute left-0 mt-2 w-48 bg-white border border-gray-200 rounded-lg shadow-lg z-20">
                {filterOptions.map((option) => (
                  <button
                    key={option}
                    className="w-full text-left px-4 py-3 hover:bg-gray-50 text-gray-700 border-b border-gray-100 last:border-b-0"
                    onClick={() => {
                      setFilterType(option);
                      setIsFilterOpen(false);
                    }}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
        
        <div className="relative max-w-md">
          <input
            type="text"
            placeholder="Search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="h-[42px] w-full px-4 py-2 border border-gray-300 rounded pr-10"
          />
          <Search className="w-5 h-5 text-gray-400 absolute right-3 top-1/2 transform -translate-y-1/2" />
        </div>

        <button 
          className="h-[42px] flex items-center gap-2 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors ml-auto"
          onClick={() => onRegisterClick && onRegisterClick()}
        >
          <Plus className="w-4 h-4" />
          <span>등록 하기</span>
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div className="bg-white border border-gray-200 rounded-lg p-6 text-center">
          <div className="text-sm text-gray-600 mb-2">월 신규 인원 수</div>
          <div className="text-2xl text-blue-600">{monthlyNewStudents}명</div>
        </div>
        <div className="bg-white border border-gray-200 rounded-lg p-6 text-center">
          <div className="text-sm text-gray-600 mb-2">전체 학생 수</div>
          <div className="text-2xl text-blue-600">{totalStudents}명</div>
        </div>
      </div>

      {/* Students Table */}
      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden mb-4">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-sm text-gray-700">카테고리</th>
                <th className="px-4 py-3 text-left text-sm text-gray-700">학생 이름</th>
                <th className="px-4 py-3 text-left text-sm text-gray-700">수업명</th>
                <th className="px-4 py-3 text-left text-sm text-gray-700">과목</th>
                <th className="px-4 py-3 text-left text-sm text-gray-700">담당 선생님</th>
                <th className="px-4 py-3 text-left text-sm text-gray-700">연락처</th>
                <th className="px-4 py-3 text-left text-sm text-gray-700">수강료</th>
                <th className="px-4 py-3 text-left text-sm text-gray-700">영수증 유무</th>
                <th className="px-4 py-3 text-center text-sm text-gray-700">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedStudents.map((student, index) => (
                <tr key={student.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <span className={`px-3 py-1 rounded-full text-xs ${
                      student.category === '신규' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {student.category}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-800">
                    <button 
                      onClick={() => {
                        setSelectedStudent(student.name);
                        if (onStudentClick) onStudentClick(student.id);
                      }}
                      className="hover:text-blue-600 hover:underline transition-colors"
                    >
                      {student.name}
                    </button>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">{student.lesson}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{student.subject}</td>
                  <td className="px-4 py-3 text-sm text-blue-500 cursor-pointer hover:underline">{student.teacher}</td>
                  <td className="px-4 py-3 text-sm text-gray-600">{student.phone}</td>
                  <td className="px-4 py-3 text-sm text-gray-800">₩{student.fee}</td>
                  <td className="px-4 py-3">
                    <span className={`px-3 py-1 rounded-full text-xs ${
                      student.receipt 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {student.receipt ? '발급' : '미발급'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-2">
                      <button className="p-1 text-blue-500 hover:bg-blue-50 rounded">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="p-1 text-red-500 hover:bg-red-50 rounded">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-center gap-2">
        <button
          onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
          disabled={currentPage === 1}
          className="p-2 border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        
        <div className="flex gap-1">
          {[...Array(Math.min(5, totalPages))].map((_, i) => {
            const pageNum = i + 1;
            return (
              <button
                key={pageNum}
                onClick={() => setCurrentPage(pageNum)}
                className={`w-8 h-8 rounded ${
                  currentPage === pageNum
                    ? 'bg-blue-500 text-white'
                    : 'border border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                {pageNum}
              </button>
            );
          })}
        </div>

        <button
          onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
          disabled={currentPage === totalPages}
          className="p-2 border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}